/// <reference types="react" />
import React from 'react';
export default class ActivityIndicatorExample extends React.Component<any, any> {
    closeTimer: any;
    constructor(props: any);
    componentWillUnmount(): void;
    loadingToast(): void;
    render(): JSX.Element;
}
