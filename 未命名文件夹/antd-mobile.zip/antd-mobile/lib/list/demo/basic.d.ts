/// <reference types="react" />
import React from 'react';
export default class BasicListExample extends React.Component<any, any> {
    render(): JSX.Element;
}
export declare const title: string;
export declare const description: string;
