/// <reference types="react" />
import React from 'react';
export default class BasicGridExample extends React.Component<any, any> {
    render(): JSX.Element;
}
