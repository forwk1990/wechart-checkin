declare var _default: {
    grayBorderBox: {
        borderColor: string;
    };
    icon: {
        width: number;
        height: number;
    };
    text: {
        fontSize: number;
        color: string;
        marginTop: number;
    };
};
export default _default;
