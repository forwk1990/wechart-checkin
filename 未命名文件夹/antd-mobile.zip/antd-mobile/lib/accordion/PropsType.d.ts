/// <reference types="react" />
import React from 'react';
interface AccordionProps {
    prefixCls?: string;
    style?: React.CSSProperties;
}
export default AccordionProps;
