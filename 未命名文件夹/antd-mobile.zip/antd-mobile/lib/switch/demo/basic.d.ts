/// <reference types="react" />
import React from 'react';
export default class SwitchExample extends React.Component<any, any> {
    constructor(props: any);
    onSwitchChange: (value: any) => void;
    render(): JSX.Element;
}
