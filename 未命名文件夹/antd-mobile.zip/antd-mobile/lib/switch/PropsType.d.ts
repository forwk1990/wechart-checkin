interface SwitchProps {
    style?: {};
    checked?: boolean;
    disabled?: boolean;
    onChange?: Function;
    prefixCls?: string;
    className?: string;
    name?: string;
}
export default SwitchProps;
