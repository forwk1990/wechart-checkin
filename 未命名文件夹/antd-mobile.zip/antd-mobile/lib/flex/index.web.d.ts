import Flex from './Flex.web';
export default Flex;
