/// <reference types="react" />
export interface IconProps {
    type: string;
    className?: string;
    title?: string;
    onClick?: (e) => void;
}
declare var _default: (props: IconProps) => JSX.Element;
export default _default;
