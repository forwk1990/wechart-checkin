/// <reference types="react" />
import React from 'react';
export default class BasicTagExample extends React.Component<any, any> {
    onChange: (e: any) => void;
    onValueChange: (value: any) => void;
    render(): JSX.Element;
}
