/// <reference types="react" />
import React from 'react';
export default class BasicTextAreaItemExample extends React.Component<any, any> {
    constructor(props: any);
    onChange: (_e: any) => void;
    onFocus: () => void;
    onBlur: () => void;
    handleError: () => void;
    render(): JSX.Element;
}
