export default function getDataAttr(props: any): {};
