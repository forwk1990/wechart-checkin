export default function splitObject(obj: any, parts: any): Array<any>;
