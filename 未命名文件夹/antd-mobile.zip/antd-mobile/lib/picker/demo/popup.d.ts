/// <reference types="react" />
import React from 'react';
export default class PopupExample extends React.Component<any, any> {
    constructor(props: any);
    onClick: () => void;
    onChange: (value: any) => void;
    render(): JSX.Element;
}
