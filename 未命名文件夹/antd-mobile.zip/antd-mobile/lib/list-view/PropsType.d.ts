interface Props {
    children?: any;
    refreshControl?: any;
    /** web only */
    prefixCls?: string;
    useZscroller?: boolean;
}
export default Props;
