/// <reference types="react" />
export default function handleProps(props: any, isIndexed: any): {
    restProps: any;
    extraProps: {
        renderHeader: any;
        renderFooter: any;
        renderSectionHeader: any;
        renderBodyComponent: () => JSX.Element;
        renderRow: any;
    };
};
