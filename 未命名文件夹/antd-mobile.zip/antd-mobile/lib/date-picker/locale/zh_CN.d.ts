export { default } from 'rmc-date-picker/lib/locale/zh_CN';
