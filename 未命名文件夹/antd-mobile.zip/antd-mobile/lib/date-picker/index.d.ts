/// <reference types="react" />
import React from 'react';
import tsPropsType from './PropsType';
export default class DatePicker extends React.Component<tsPropsType, any> {
    static defaultProps: any;
    render(): JSX.Element;
}
