/// <reference types="react" />
import React from 'react';
import 'moment/locale/zh-cn';
export default class PopupExample extends React.Component<any, any> {
    date1MinDate: any;
    date1MaxDate: any;
    constructor(props: any);
    onChange: (value: any) => void;
    render(): JSX.Element;
}
