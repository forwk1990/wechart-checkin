/// <reference types="react" />
import React from 'react';
export default class BasicRadioExample extends React.Component<any, any> {
    state: {
        part1Value: number;
        part2Value: number;
    };
    render(): JSX.Element;
}
