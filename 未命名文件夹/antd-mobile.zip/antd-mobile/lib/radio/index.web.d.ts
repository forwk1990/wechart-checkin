import Radio from './Radio.web';
export default Radio;
