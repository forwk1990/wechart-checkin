/// <reference types="react" />
import React from 'react';
export default class BasicWingBlankExample extends React.Component<any, any> {
    render(): JSX.Element;
}
