/// <reference types="react" />
import React from 'react';
export default class BasicCarouselExample extends React.Component<any, any> {
    onselectedIndexChange(index: any): void;
    render(): JSX.Element;
}
