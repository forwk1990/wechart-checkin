declare var _default: {
    icon: {
        width: number;
        height: number;
    };
    agreeItem: {
        flexDirection: string;
        alignItems: string;
    };
    agreeItemCheckbox: {
        marginLeft: number;
        marginRight: number;
    };
    checkboxItemCheckbox: {
        marginRight: number;
        alignSelf: string;
    };
};
export default _default;
