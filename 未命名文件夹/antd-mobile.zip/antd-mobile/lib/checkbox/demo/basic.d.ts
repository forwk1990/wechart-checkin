/// <reference types="react" />
import React from 'react';
export default class BasicCheckboxExample extends React.Component<any, any> {
    constructor(props: any, context: any);
    render(): JSX.Element;
}
