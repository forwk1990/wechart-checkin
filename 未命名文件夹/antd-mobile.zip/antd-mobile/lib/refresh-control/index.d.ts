import { RefreshControl } from 'react-native';
export default RefreshControl;
