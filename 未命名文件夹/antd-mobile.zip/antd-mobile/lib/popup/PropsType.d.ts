export interface PopupProps {
    animationType?: string;
    maskClosable?: boolean;
    visible: boolean;
}
export default PopupProps;
