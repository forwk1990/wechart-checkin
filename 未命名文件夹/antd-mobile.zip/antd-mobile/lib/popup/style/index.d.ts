/// <reference types="react-native" />
import { ViewStyle } from 'react-native';
declare var _default: {
    wrap: ViewStyle;
    wrapTop: ViewStyle;
};
export default _default;
