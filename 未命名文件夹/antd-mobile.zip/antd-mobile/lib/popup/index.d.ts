declare var _default: {
    show(content: any, options: any): void;
    hide(): void;
};
export default _default;
