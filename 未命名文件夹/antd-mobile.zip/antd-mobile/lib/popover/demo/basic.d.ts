/// <reference types="react" />
import React from 'react';
export default class PopoverExample extends React.Component<any, any> {
    constructor(props: any);
    onSelect: (value: any) => void;
    render(): JSX.Element;
}
export declare const title: string;
export declare const description: string;
