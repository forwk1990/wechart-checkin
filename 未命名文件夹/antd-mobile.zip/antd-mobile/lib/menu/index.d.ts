/// <reference types="react" />
import React from 'react';
import { MenuProps, MenuState } from './PropsType';
export default class AntMenu extends React.Component<MenuProps, MenuState> {
    static defaultProps: {};
    render(): JSX.Element;
}
