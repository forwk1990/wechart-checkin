/// <reference types="react" />
import React from 'react';
import TabsProps from './PropsType';
declare const Tabs: React.ClassicComponentClass<TabsProps>;
export default Tabs;
