/// <reference types="react" />
import React from 'react';
export default class TabPane extends React.Component<any, any> {
    render(): JSX.Element;
}
