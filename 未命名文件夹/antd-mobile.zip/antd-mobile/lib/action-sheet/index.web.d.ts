declare var _default: {
    showActionSheetWithOptions(config: any, callback?: () => void): void;
    showShareActionSheetWithOptions(config: any, callback?: () => void): void;
    close(): void;
};
export default _default;
