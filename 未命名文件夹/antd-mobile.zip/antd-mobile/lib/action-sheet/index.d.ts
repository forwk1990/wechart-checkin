export interface Props {
    name?: string;
    maskClosable?: boolean;
}
declare let ActionSheet: any;
export default ActionSheet;
