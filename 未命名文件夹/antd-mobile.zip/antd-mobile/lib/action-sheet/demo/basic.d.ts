/// <reference types="react" />
import React from 'react';
declare var _default: React.ClassicComponentClass<{}>;
export default _default;
export declare const title: string;
export declare const description: string;
