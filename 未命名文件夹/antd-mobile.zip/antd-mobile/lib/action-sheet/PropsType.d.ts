interface Props {
    children?: any;
    /** web only */
    prefixCls?: string;
}
export default Props;
