/// <reference types="react" />
import React from 'react';
export default class BasicWhiteSpaceExample extends React.Component<any, any> {
    render(): JSX.Element;
}
