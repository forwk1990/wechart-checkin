/// <reference types="react" />
import React from 'react';
export default class Table extends React.Component<any, any> {
    static defaultProps: {
        dataSource: never[];
        prefixCls: string;
    };
    render(): JSX.Element;
}
