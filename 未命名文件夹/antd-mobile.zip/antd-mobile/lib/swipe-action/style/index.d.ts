declare var _default: {
    actions: {
        flexDirection: string;
    };
    buttonWrap: {
        borderTopWidth: number;
        borderTopColor: string;
        borderStyle: string;
        paddingVertical: number;
    };
    button: {
        textAlign: string;
        color: string;
        fontSize: number;
    };
};
export default _default;
