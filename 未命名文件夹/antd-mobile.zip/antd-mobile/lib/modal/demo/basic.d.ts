/// <reference types="react" />
import React from 'react';
export default class BasicModalExample extends React.Component<any, any> {
    constructor(props: any);
    showModal: () => void;
    showModal2: () => void;
    onClose: () => void;
    onClose2: () => void;
    render(): JSX.Element;
}
