export default function (...args: any[]): void;
