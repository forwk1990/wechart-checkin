/// <reference types="react-native" />
import { ViewStyle } from 'react-native';
declare var _default: {
    input: ViewStyle;
    wrapper: ViewStyle;
    cancelTextContainer: ViewStyle;
    cancelText: ViewStyle;
    search: ViewStyle;
};
export default _default;
