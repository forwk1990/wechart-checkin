export { View as default } from 'react-native';
