/// <reference types="react" />
import React from 'react';
export default class BasicInputItemExample extends React.Component<any, any> {
    constructor(props: any);
    render(): JSX.Element;
}
