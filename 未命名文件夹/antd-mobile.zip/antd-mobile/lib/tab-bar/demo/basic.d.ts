/// <reference types="react" />
import React from 'react';
export default class BasicTabBarExample extends React.Component<any, any> {
    constructor(props: any);
    renderContent(pageText: any, num?: number): JSX.Element;
    render(): JSX.Element;
}
