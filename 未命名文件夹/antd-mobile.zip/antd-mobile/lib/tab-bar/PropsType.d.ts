interface TabBarProps {
    barTintColor?: string;
    tintColor?: string;
    unselectedTintColor?: string;
    children: any;
    prefixCls?: string;
    className?: string;
    hidden?: boolean;
}
export default TabBarProps;
