/// <reference types="react" />
import React from 'react';
declare const AntTabBar: React.ClassicComponentClass<{
    prefixCls: string;
    barTintColor: string;
    tintColor: string;
    unselectedTintColor: string;
}>;
export default AntTabBar;
