/// <reference types="react" />
import React from 'react';
declare class Tab extends React.Component<any, any> {
    render(): JSX.Element;
}
export default Tab;
