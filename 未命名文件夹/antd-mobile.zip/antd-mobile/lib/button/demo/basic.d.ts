/// <reference types="react" />
declare var _default: () => JSX.Element;
export default _default;
