/// <reference types="react" />
import React from 'react';
export default class BasicSliderExample extends React.Component<any, any> {
    constructor(props: any);
    handleChange: (value: any) => void;
    onAfterChange: (value: any) => void;
    minMaxChange: (value: any) => void;
    render(): JSX.Element;
}
