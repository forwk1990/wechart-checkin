/// <reference types="react" />
import React from 'react';
export default class StepperExample extends React.Component<any, any> {
    render(): JSX.Element;
}
