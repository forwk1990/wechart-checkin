/// <reference types="react" />
import React from 'react';
export default class ToastExample extends React.Component<any, any> {
    componentDidMount(): void;
    componentWillUnmount(): void;
    render(): JSX.Element;
}
