declare var _default: {
    progressOuter: {
        backgroundColor: string;
        flex: number;
    };
    progressBar: {
        borderBottomWidth: number;
        borderStyle: string;
        borderColor: string;
    };
};
export default _default;
