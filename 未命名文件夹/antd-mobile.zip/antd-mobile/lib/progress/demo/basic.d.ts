/// <reference types="react" />
import React from 'react';
export default class BasicProgressExample extends React.Component<any, any> {
    constructor(props: any);
    onAdd: () => void;
    render(): JSX.Element;
}
